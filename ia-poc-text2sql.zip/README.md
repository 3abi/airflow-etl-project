
# Text to SQL PoC avec LLM phi3

## Lancement du projet

```bash
docker compose up --build
```

## Interface

Accéder à : http://localhost:8000

Tapez une question en français, et le système génère la requête SQL et exécute sur PostgreSQL.
