
CREATE TABLE IF NOT EXISTS produits (
  id SERIAL PRIMARY KEY,
  nom TEXT,
  quantite INT
);

INSERT INTO produits (nom, quantite) VALUES
('Stylo', 120),
('Cahier', 300),
('Crayon', 250);
