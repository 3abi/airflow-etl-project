
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import httpx
import psycopg2
import os

app = FastAPI()
origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Query(BaseModel):
    prompt: str

@app.post("/query")
async def query_data(data: Query):
    async with httpx.AsyncClient() as client:
        res = await client.post("http://ollama:11434/api/generate", json={
            "model": "phi3",
            "prompt": f"Convertis cette demande en SQL: {data.prompt}",
            "stream": False
        })
        generated = res.json()["response"]

    try:
        conn = psycopg2.connect(
            host=os.getenv("POSTGRES_HOST", "postgres"),
            port=os.getenv("POSTGRES_PORT", 5432),
            database=os.getenv("POSTGRES_DB", "demo"),
            user=os.getenv("POSTGRES_USER", "demo"),
            password=os.getenv("POSTGRES_PASSWORD", "demo")
        )
        cur = conn.cursor()
        cur.execute(generated)
        rows = cur.fetchall()
        columns = [desc[0] for desc in cur.description]
        cur.close()
        conn.close()
        return {"query": generated, "result": [dict(zip(columns, row)) for row in rows]}
    except Exception as e:
        return {"query": generated, "error": str(e)}
