
# ia-agent-poc-phi3

## Lancer le projet

```bash
docker compose up --build
```

## Accéder à l'interface

http://localhost:8000

## Tester l'API

```bash
curl -X POST http://localhost:8000/query -H "Content-Type: application/json" -d '{"prompt": "Quels sont les avantages de l’open data ?"}'
```
