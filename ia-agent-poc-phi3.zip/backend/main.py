
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import httpx

app = FastAPI()

origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Query(BaseModel):
    prompt: str

@app.post("/query")
async def query_llm(data: Query):
    async with httpx.AsyncClient() as client:
        response = await client.post("http://ollama:11434/api/generate", json={
            "model": "phi3",
            "prompt": data.prompt,
            "stream": False
        })
        return response.json()
