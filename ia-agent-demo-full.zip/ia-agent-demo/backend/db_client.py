import psycopg2

def execute_query_postgres(query):
    conn = psycopg2.connect(
        dbname="demo", user="user", password="pass", host="postgres"
    )
    cur = conn.cursor()
    cur.execute(query)
    columns = [desc[0] for desc in cur.description]
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return [dict(zip(columns, row)) for row in rows]
