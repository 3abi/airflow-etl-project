# Agent IA Demo (100% Docker + LLM intégré)

## Étapes

### 1. Depuis une machine avec accès Internet
```bash
# Cloner et builder le conteneur Ollama avec le modèle
docker build -t ollama-llama3 -f Dockerfile.ollama .
docker save ollama-llama3 > ollama-llama3.tar
```

### 2. Copier le fichier `ollama-llama3.tar` dans l’environnement restreint
```bash
docker load < ollama-llama3.tar
```

### 3. Lancer l’environnement complet
```bash
docker compose up --build
```

### 4. Accéder à l’interface
```
http://localhost:8000
```

Tapez un prompt comme :
```
Quels sont les 5 derniers clients enregistrés ?
```

Et l’agent IA générera la requête SQL avec llama3 et affichera les résultats.
