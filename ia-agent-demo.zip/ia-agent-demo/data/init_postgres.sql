CREATE TABLE clients (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100),
    date_inscription DATE
);

INSERT INTO clients (nom, date_inscription) VALUES
('Alice', '2024-01-12'),
('Bob', '2024-03-22'),
('Sophie', '2024-10-01'),
('Ali', '2024-09-29'),
('Nina', '2024-08-15');
