# Agent IA Demo

## Lancer la démo

1. Installer Ollama et lancer le modèle : `ollama run llama3`
2. Démarrer les services :
```bash
docker compose up --build
```
3. Accéder au frontend : http://localhost:8000 ou tester l’API via /docs
