import requests

def generate_sql_query(prompt):
    payload = {"model": "llama3", "prompt": f"Convert this to SQL: {prompt}"}
    response = requests.post("http://ollama:11434/api/generate", json=payload)
    return response.json().get("response", "").strip()
