from fastapi import FastAPI, Request
from db_client import execute_query_postgres
from llm_prompt import generate_sql_query

app = FastAPI()

@app.post("/query")
async def handle_prompt(request: Request):
    data = await request.json()
    prompt = data["prompt"]
    query = generate_sql_query(prompt)
    results = execute_query_postgres(query)
    return {"query": query, "results": results}
